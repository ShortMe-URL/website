

<?php $__env->startSection('title', 'Your URLs'); ?>

<?php $__env->startSection('body'); ?>
    <div class="container" id="shorter">
        <div class="machine" style="--image-illu: url(<?php echo e(Vite::asset('resources/images/illu.svg')); ?>);">
            <h1>Short Your Link:</h1>
            <form action="<?php echo e(route('shorturl.short')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="url-sub">
                    <input type="url" name="url" id="url" placeholder="Insert your awesome url" class="url"
                        required value="<?php echo e(old('url')); ?>" />
                    <input type="submit" id="submit" value="Short it!">
                </div>
                <p id="advopt"><i class="fas fa-plus"></i> Advanced Options</p>
                <div class="advopt-inputs row">
                    <div class="input-content-group col-sm-6 col-12">
                        <label for="delete_at">Delete After:</label>
                        <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'delete_at']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'delete_at']); ?>
                            <option value="1day" <?php echo e(old('delete_at') === '1day' ? 'selected' : ''); ?>>After 1 Day</option>
                            <option value="3day" <?php echo e(old('delete_at') === '3day' ? 'selected' : ''); ?>>After 3 Day</option>
                            <option value="7day" <?php echo e(old('delete_at') === '7day' ? 'selected' : ''); ?>>After 7 Day</option>
                            <option value="1month"
                                <?php echo e(old('delete_at') === '1month' ? 'selected' : (old('delete_at') ? '' : 'selected')); ?>>
                                After a Month</option>
                            <option value="1year" <?php echo e(old('delete_at') === '1year' ? 'selected' : ''); ?>>After a Year
                            </option>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
                    </div>
                    <div class="input-content-group col-sm-6 col-12">
                        <label for="password">Password</label>
                        <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['name' => 'password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                    </div>
                    <?php if(auth()->user()->premium === true): ?>
                        <div class="input-content-group col-12">
                            <label for="shortpath">Custom URL</label>
                            <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['name' => 'shortpath','placeholder' => ''.e(env('PREMIUM_LINKS_URL') . '/CUSTOM-ID').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'shortpath','placeholder' => ''.e(env('PREMIUM_LINKS_URL') . '/CUSTOM-ID').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
                <?php if($errors->any()): ?>
                    <div class="error"><?php echo e($errors->first()); ?></div>
                <?php endif; ?>
            </form>
        </div>

        <?php if(session('shorturl_created')): ?>
            <div class="shorted">
                <div class="url">
                    
                    <div class="short"><?php echo e(session('shorturl_data')->getFullURL()); ?></div>
                </div>
                <button
                    onclick="(navigator.clipboard.writeText(this.parentElement.querySelector('.url .short')?.innerText),document.execCommand('copy'),this.classList.add('copied'),this.innerText = 'Copied', window.setTimeout(() => (this.innerText = 'Copy', this.classList.remove('copied')), 2000))">
                    Copy
                </button>
            </div>
        <?php endif; ?>
    </div>
    <section class="container">
        <?php if($userLinks->count() > 0): ?>
            <form id="optionsForm" action="<?php echo e(route('dashboard.myurls')); ?>" method="get">
                <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'sort']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'sort']); ?>
                    <option value="newtoold" <?php echo e(request('sort') === 'newtoold' ? 'selected' : ''); ?>>Newest to Oldest
                    </option>
                    <option value="oldtonew" <?php echo e(request('sort') === 'oldtonew' ? 'selected' : ''); ?>>Oldest to Newest
                    </option>
                    <option value="mostclicks" <?php echo e(request('sort') === 'mostclicks' ? 'selected' : ''); ?>>Most Clicks
                    </option>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
                <button type="submit">Filter</button>
            </form>

            <div style="overflow-x: auto;border-radius: 15px;">
                <table>
                    <tr>
                        <th>Link</th>
                        <th>Password</th>
                        <th>Clicks</th>
                        <th>Created At</th>
                        <th>Deletes At</th>
                        <th></th>
                    </tr>
                    <?php $__currentLoopData = $userLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($link->getFullURL()); ?></th>
                            <th><?php echo e($link->password ? 'Yes' : 'No'); ?></th>
                            <th><?php echo e($link->clicks()->count()); ?></th>
                            <th><?php echo e($link->created_at->format('Y-m-d')); ?></th>
                            <th><?php echo e($link->delete_at ? \Carbon\Carbon::parse($link->delete_at)->format('Y-m-d') : 'Never'); ?>

                            </th>
                            <th><button onclick="deleteLink(this);" data-deleteURL="<?php echo e(route('dashboard.myurls.delete', $link->id)); ?>">Delete</button>
                            </th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        <?php else: ?>
            <h2 style="color: var(--nav-text);">You didn't short any link yet!</h2>
        <?php endif; ?>

    </section>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/myurls.js'); ?>
    <script>
        /**
         * @param {HTMLButtonElement} button 
         */
        function deleteLink(button) {
            Swal.fire({
                title: "Are you sure you want to delete the URL?",
                showCancelButton: true,
                confirmButtonText: "Delete",
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch(button.getAttribute('data-deleteURL'), {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json",
                                "X-CSRF-TOKEN": '<?php echo e(csrf_token()); ?>'
                            },
                            body: JSON.stringify({
                                _method: 'DELETE'
                            })
                        })
                        .then(response => response.ok ? button.closest('tr').remove() : Promise.reject())
                        .then(() => Swal.fire("Deleted!", "The URL has been deleted.", "success"))
                        .catch(() => Swal.fire("Error!", "An error occurred while trying to delete the URL.",
                            "error"));
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/pages/dashboard/myurls.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/bootstrap-grid.min.css'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\Desktop\Other MMC Projects\shortme\resources\views/dashboard/myurls.blade.php ENDPATH**/ ?>