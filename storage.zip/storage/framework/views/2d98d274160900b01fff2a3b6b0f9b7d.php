

<?php $__env->startSection('title', 'Analytics'); ?>

<?php $__env->startSection('body'); ?>
    <section class="container">
        <div class="row">
            
            <div class="col-md-4 col-sm-6 col-12">
                <div class="sic">
                    <h2>Links Count</h2>
                    <span><?php echo e($linksCount); ?></span>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-12">
                <div class="sic">
                    <h2>Clicks Count</h2>
                    <span><?php echo e($clicksCount); ?></span>
                </div>
            </div>
            <div class="col-md-4 col-12">
                <div class="sic">
                    <h2>Something</h2>
                    <span>?</span>
                </div>
            </div>

            
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3>Clicks</h3><span>(This year)</span>
                    </div>
                    <div class="card-content">
                        <canvas id="clicksChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php echo app('Illuminate\Foundation\Vite')('node_modules/chart.js/dist/chart.umd.js'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/analytics.js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/pages/dashboard/analytics.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/bootstrap-grid.min.css'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\Desktop\Other MMC Projects\shortme\resources\views/dashboard/analytics.blade.php ENDPATH**/ ?>