<nav>
    <div class="container">
        <div class="logo">
            <a href="/">
                <img src="<?php echo e(Vite::asset('resources/images/link.svg')); ?>">
                <span class="brand-name">Shortme</span>
            </a>
        </div>
        <div class="bars" id="nav_btn"><i class="far fa-bars"></i></div>
        <ul class="list">
            <?php if(Request::is('dashboard*')): ?>
                <?php if (isset($component)) { $__componentOriginal5e6cebcbcdf13f018dd76113c2a8dd58 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5e6cebcbcdf13f018dd76113c2a8dd58 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navitem','data' => ['href' => ''.e(route('dashboard')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navitem'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('dashboard')).'']); ?><i class="fad fas fa-chart-line"></i> Dashboard <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5e6cebcbcdf13f018dd76113c2a8dd58)): ?>
<?php $attributes = $__attributesOriginal5e6cebcbcdf13f018dd76113c2a8dd58; ?>
<?php unset($__attributesOriginal5e6cebcbcdf13f018dd76113c2a8dd58); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5e6cebcbcdf13f018dd76113c2a8dd58)): ?>
<?php $component = $__componentOriginal5e6cebcbcdf13f018dd76113c2a8dd58; ?>
<?php unset($__componentOriginal5e6cebcbcdf13f018dd76113c2a8dd58); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal5e6cebcbcdf13f018dd76113c2a8dd58 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5e6cebcbcdf13f018dd76113c2a8dd58 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navitem','data' => ['href' => ''.e(route('dashboard.myurls')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navitem'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('dashboard.myurls')).'']); ?><i class="fad fas fa-link"></i> My Urls <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5e6cebcbcdf13f018dd76113c2a8dd58)): ?>
<?php $attributes = $__attributesOriginal5e6cebcbcdf13f018dd76113c2a8dd58; ?>
<?php unset($__attributesOriginal5e6cebcbcdf13f018dd76113c2a8dd58); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5e6cebcbcdf13f018dd76113c2a8dd58)): ?>
<?php $component = $__componentOriginal5e6cebcbcdf13f018dd76113c2a8dd58; ?>
<?php unset($__componentOriginal5e6cebcbcdf13f018dd76113c2a8dd58); ?>
<?php endif; ?>
                <li>
                    <form action="<?php echo e(route('logout')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <a href="javascript:{}" onclick="this.parentNode.submit();"><i class="fad fa-left-from-bracket"></i> Logout</a>
                    </form>
                </li>
            <?php else: ?>
                <?php if(auth()->guard()->check()): ?>
                    <li class="login">
                        <a href="<?php echo e(route('dashboard')); ?>"><i class="fad fas fa-chart-line"></i> Dashboard</a>
                    </li>
                <?php else: ?>
                    <li class="login">
                        <a href="<?php echo e(route('login')); ?>"><i class="fad fa-sign-in-alt"></i> Login</a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
        </ul>
    </div>
</nav>

<div class="theme-switcher light" id="theme-switcher">
    <i class="fas fa-sun"></i>
</div>
<?php /**PATH P:\Desktop\Other MMC Projects\shortme\resources\views/layouts/nav.blade.php ENDPATH**/ ?>