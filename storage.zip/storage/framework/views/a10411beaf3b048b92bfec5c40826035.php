<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="<?php echo e(Vite::asset('resources/images/favicon.png')); ?>" type="image/png" sizes="16x16">
    
    <meta name="description" content="">
    <meta name="og:description" content="">
    <meta name="og:title" content="">
    <meta name="og:image" content="">

    
    <?php if (! empty(trim($__env->yieldContent('title')))): ?>
        <title>ShortMe - <?php echo $__env->yieldContent('title'); ?></title>
    <?php else: ?>
        <title>ShortMe</title>
    <?php endif; ?>

    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.5.2/css/all.css">

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/normalize.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/navbar.css'); ?>

    <?php echo $__env->yieldContent('head'); ?>
</head>

<body>
    <?php echo $__env->make("layouts.nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('body'); ?>

    <?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo app('Illuminate\Foundation\Vite')('/resources/js/app.js'); ?>
    <?php echo $__env->yieldContent('js'); ?>
</body>

</html>
<?php /**PATH P:\Desktop\Other MMC Projects\shortme\resources\views/layouts/html.blade.php ENDPATH**/ ?>