

<?php $__env->startSection('body'); ?>
    <section class="landing">
        <div class="container">
            <div class="col1">
                <h1>More than just shorter links</h1>
                <p>
                    Build your brand's recognition and get detailed insights on how your
                    links are performing!
                </p>
                <a href="<?php echo e(route('login')); ?>">Get Started</a>
            </div>
            <div class="col2">
                <img src="<?php echo e(Vite::asset('resources/images/landing.svg')); ?>">
            </div>
        </div>
    </section>
    <section class="shorter">
        <div class="machine" style="--image-illu: url(<?php echo e(Vite::asset('resources/images/illu.svg')); ?>);">
            <div class="container">
                <form action="<?php echo e(route('shorturl.short')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="url" name="url" id="url" placeholder="Insert your awesome url" class="url"
                        required>
                    <input type="submit" value="Short it!" id="submit">
                </form>

                <?php if($errors->any()): ?>
                    <div class="error_message error"><?php echo e($errors->first()); ?></div>
                <?php endif; ?>
            </div>
        </div>
        <div class="container">
            <?php if(session('shorturl_created')): ?>
                <div class="shorted">
                    <div class="url">
                        
                        <div class="short"><?php echo e(session('shorturl_data')->getFullURL()); ?></div>
                    </div>
                    <button
                        onclick="(navigator.clipboard.writeText(this.parentElement.querySelector('.url .short')?.innerText),document.execCommand('copy'),this.classList.add('copied'),this.innerText = 'Copied', window.setTimeout(() => (this.innerText = 'Copy', this.classList.remove('copied')), 2000))">
                        Copy
                    </button>
                </div>
            <?php endif; ?>

            <div class="features">
                <h6>Control and Manage Everything</h6>
                <h2>Advanced Statistics</h2>
                <div class="_features">
                    <div class="feature">
                        <span class="i"><i class="fad fa-pencil-paintbrush"></i></span>
                        <h3>Fully Customizable</h3>
                    </div>
                    <div class="feature">
                        <span class="i"><i class="fas fa-tachometer-alt-slow"></i></span>
                        <h3>Powerful Dashboard</h3>
                    </div>
                    <div class="feature">
                        <span class="i"><i class="fas fa-analytics"></i></span>
                        <h3>Statistics</h3>
                    </div>
                </div>
                <p>
                    Track how your links are performing across the web with our advanced
                    statistics dashboard
                </p>
            </div>
        </div>
    </section>
    <section class="stats">
        <div class="container">
            <h1>Marketing with confidence.</h1>
            <div class="stats">
                <div class="col">
                    <h3>Powering</h3>
                    <h2><?php echo e($linksCount); ?><span>Links</span></h2>
                </div>
                <div class="col">
                    <h3>Serving</h3>
                    <h2><?php echo e($clicksCount); ?><span>Clicks</span></h2>
                </div>
                <div class="col">
                    <h3>Trusted By</h3>
                    <h2><?php echo e($usersCount); ?><span>Customers</span></h2>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/pages/welcome.css'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\Desktop\Other MMC Projects\shortme\resources\views/welcome.blade.php ENDPATH**/ ?>