<footer>
    <a href="https:/github.com/MohammedMMc">MohammedMMc</a> ©2025
</footer>
<?php /**PATH P:\Desktop\Other MMC Projects\shortme\resources\views/layouts/footer.blade.php ENDPATH**/ ?>